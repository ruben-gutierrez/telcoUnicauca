import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-foromovil',
  templateUrl: './foromovil.component.html',
  styleUrls: ['./foromovil.component.css']
})
export class ForomovilComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
