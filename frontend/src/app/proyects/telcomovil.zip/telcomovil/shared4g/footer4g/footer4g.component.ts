import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer4g',
  templateUrl: './footer4g.component.html',
  styleUrls: ['./footer4g.component.css']
})
export class Footer4gComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
