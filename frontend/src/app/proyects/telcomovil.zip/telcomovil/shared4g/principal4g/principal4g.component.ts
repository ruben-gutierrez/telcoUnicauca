import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-principal4g',
  templateUrl: './principal4g.component.html',
  styleUrls: ['./principal4g.component.css']
})
export class Principal4gComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
