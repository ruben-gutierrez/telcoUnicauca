import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-asideleft4g',
  templateUrl: './asideleft4g.component.html',
  styleUrls: ['./asideleft4g.component.css']
})
export class Asideleft4gComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
