import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contacto4g',
  templateUrl: './contacto4g.component.html',
  styleUrls: ['./contacto4g.component.css']
})
export class Contacto4gComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
