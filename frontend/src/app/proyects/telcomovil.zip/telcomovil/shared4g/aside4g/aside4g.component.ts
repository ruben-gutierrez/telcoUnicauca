import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aside4g',
  templateUrl: './aside4g.component.html',
  styleUrls: ['./aside4g.component.css']
})
export class Aside4gComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
