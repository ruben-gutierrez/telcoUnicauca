import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menumovil',
  templateUrl: './menumovil.component.html',
  styleUrls: ['./menumovil.component.css']
})
export class MenumovilComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
