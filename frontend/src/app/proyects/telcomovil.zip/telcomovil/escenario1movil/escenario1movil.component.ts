import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-escenario1movil',
  templateUrl: './escenario1movil.component.html',
  styleUrls: ['./escenario1movil.component.css']
})
export class Escenario1movilComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
