import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-iniciomovil',
  templateUrl: './iniciomovil.component.html',
  styleUrls: ['./iniciomovil.component.css']
})
export class IniciomovilComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
