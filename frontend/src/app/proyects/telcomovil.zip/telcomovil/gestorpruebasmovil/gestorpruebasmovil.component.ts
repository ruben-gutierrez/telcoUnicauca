import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gestorpruebasmovil',
  templateUrl: './gestorpruebasmovil.component.html',
  styleUrls: ['./gestorpruebasmovil.component.css']
})
export class GestorpruebasmovilComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
