import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-escenario2movil',
  templateUrl: './escenario2movil.component.html',
  styleUrls: ['./escenario2movil.component.css']
})
export class Escenario2movilComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
