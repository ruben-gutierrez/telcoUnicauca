import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pruebasmovil',
  templateUrl: './pruebasmovil.component.html',
  styleUrls: ['./pruebasmovil.component.css']
})
export class PruebasmovilComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
