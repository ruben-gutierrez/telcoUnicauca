import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-informacionmovil',
  templateUrl: './informacionmovil.component.html',
  styleUrls: ['./informacionmovil.component.css']
})
export class InformacionmovilComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
