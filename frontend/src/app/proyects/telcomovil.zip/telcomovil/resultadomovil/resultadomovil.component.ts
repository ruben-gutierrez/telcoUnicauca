import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-resultadomovil',
  templateUrl: './resultadomovil.component.html',
  styleUrls: ['./resultadomovil.component.css']
})
export class ResultadomovilComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
