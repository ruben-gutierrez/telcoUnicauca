import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-guiasmovil',
  templateUrl: './guiasmovil.component.html',
  styleUrls: ['./guiasmovil.component.css']
})
export class GuiasmovilComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
