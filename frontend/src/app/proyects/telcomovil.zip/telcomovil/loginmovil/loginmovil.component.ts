import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loginmovil',
  templateUrl: './loginmovil.component.html',
  styleUrls: ['./loginmovil.component.css']
})
export class LoginmovilComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
